<?php
session_start();
require_once 'connect.php';
$id = $_GET['id'];
$cel = $_POST['cel'];
$koniec = $_POST['koniec'];
$id_user = $_SESSION['id'];
$czy_zrealizowano = 1;

        // $zapytanie = mysqli_query($polaczenie, "DELETE FROM cele WHERE id = '$id'");
        $zapytanie = mysqli_query($polaczenie, "UPDATE cele SET czy_zrealizowano=$czy_zrealizowano WHERE id='$id'");


        // if(mysqli_query($polaczenie, $zapytanie))
        // {
        //  $polaczenie->query("INSERT INTO cele_zrealizowane (tresc, data_nr, ) VALUES ('$cel', '$koniec')");
        // if(mysqli_query($polaczenie, $zapytanie))
        // {
        //     $polaczenie->query("UPDATE cele SET czy_zrealizowano=$czy_zrealizowano");
        // }

        mysqli_close($polaczenie);
        header("location:cel.php");

        // }   else
        // {
        // echo "Error deleting record";
        // }

	// if ($value == 1) {

    // }


	?>