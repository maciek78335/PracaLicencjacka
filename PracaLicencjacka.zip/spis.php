<?php
session_start();

require_once 'connect.php';

?>


<!DOCTYPE HTML>
<html lang="pl">

<head>
	<meta charset="utf-8" />
	<title>Jadłospis</title>
</head>
<style>
	body {
		background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('dieta.jpg');
		min-height: 100%;
		background-position: center;
		background-size: cover;
		color: white;
	}

	.formContent {
		background-color: #E0E0E0;
		color: black;
		margin-bottom: 10px;
		text-align: center;
		margin-left: auto;
		margin-right: auto;
		padding: 40px;
		margin-top: 10px;

	}

	input[type=text],
	input[type=date] {
		width: 300px;
		background-color: #efefef;
		color: #666;
		border: 2px solid #ddd;
		border-radius: 5px;
		font-size: 15px;
		padding: 5px;
		box-sizing: border-box;
		outline: none;
		margin-top: 10px;
	}

	input[type=submit] {
		width: 300px;
		background-color: #36b03c;
		font-size: 15px;
		color: white;
		padding: 10px 5px;
		margin-top: 20px;
		border: none;
		border-radius: 5px;
		cursor: pointer;
	}

	input[type=submit]:hover {
		background-color: #37b93d;
	}

	table {
		border: 1px solid;
		margin-top: 10px;
		margin-left: 10px;
		color: white;
		float: left;
		text-align: center;
	}


	td {
		border: 1px solid;
		padding: 5px;
	}

	th {
		background-color: #04AA6D;
		border: 1px solid;
		padding: 10px;

	}

	.tabele form {
		background-color: #E0E0E0;
		color: black;
		padding: 40px;
		margin-top: 20px;
		width: 370px;
		text-align: center;
		margin-left: auto;
		margin-right: auto;
	}
</style>

<body>
	<?php
	require_once 'nawigacja.php';
	function wyswietlWszystkieDni()
	{

		$host = "localhost";
		$db_user = "root";
		$db_password = "";
		$db_name = "pomiary";
		$polaczenie = mysqli_connect($host, $db_user, $db_password, $db_name);
		$id_user = $_SESSION['id'];
		$query = "SELECT * FROM obliczane_kalorie WHERE id_user = '$id_user' ORDER BY nr_data";
		$wynikZapytania = $polaczenie->query($query);



		echo '<div class="col-6">';
		echo '<table>';
		echo '<tr><th>' . "Data" . '</th>';
		echo '<th>' . "Kcal" . '</th>';
		echo '<th>' . "Tłuszcze" . '</th>';
		echo '<th>' . "Węglowodany" . '</th>';
		echo '<th>' . "Białko" . '</th></tr>';
		if (mysqli_query($polaczenie, $query)) {
			if ($wynikZapytania->num_rows > 0) {
				while ($row = mysqli_fetch_array($wynikZapytania)) {
					echo '<tr><td>' . $row['nr_data'] . '</td>' . '<td>' .
						$row["kcal"] . '</td>' . '<td>' . " " . $row["tluszcze"] . '</td>' . '<td>' .
						$row["weglowodany"] . '</td>' . '<td>'
						. $row["bialko"] . '</td></tr>';
				}
			}
		}
		echo '</table>';
		echo '</div>';
		$polaczenie->close();
	} ?>
	<section class="tabele">
		<div class="container">
			<div class="row">

				<div class="col-6">
					<form class="form-content" action="" method="post">
						Posiłek: </br> <select name="poraDnia">
							<option value="" disabled selected>Wybierz porę dnia:</option>
							<option value="sniadanie">Śniadanie</option>
							<option value="obiad">Obiad</option>
							<option value="przekaska">Przekąska</option>
							<option value="kolacja">Kolacja</option>
						</select> <br /><br />
						Produkt: <br /> <select name="produkt">
							<option value="" disabled selected>Wybierz produkt:</option>
							<?php
							$zapytanie = "SELECT nazwa FROM produkty";
							$wiersze = mysqli_query($polaczenie, $zapytanie);
							if (!$wiersze) {
								printf("Error: %s\n", mysqli_error($polaczenie));
								exit();
							}

							while ($dane = mysqli_fetch_array($wiersze)) {
								echo "<option value=" . $dane['nazwa'] . ">" . $dane['nazwa'] . "</option>";
							}
							
							?>
						</select> <br /><br />

						Data: <br /> <input type="date" name="nr_data" /> <br /><br />
						<input type="submit" name="submit" value="Wstaw produkt do jadłospisu" />
					</form>
				</div>

				<?php
				if (isset($_SESSION['zalogowany'])) {

					if (isset($_POST['produkt'])) {
						if (!empty($_POST['poraDnia']) && !empty($_POST['produkt']) && !empty($_POST['nr_data'])) {
							$flag = true;
							$id_user = $_SESSION['id'];
							$produkt = $_POST['produkt'];
							$data = $_POST['nr_data'];
							$selected = $_POST['poraDnia'];
							$zapytanie = "SELECT * FROM produkty WHERE nazwa = '$produkt'";

							$result = $polaczenie->query($zapytanie);

							if (mysqli_query($polaczenie, $zapytanie)) {

								if ($result->num_rows > 0) {

									while ($row = mysqli_fetch_array($result)) {

										$id_produktu = $row['id'];
										$nazwa = $row['nazwa'];
										$kcal = $row['kcal'];
										$tluszcze = $row['tluszcze'];
										$weglowodany = $row['weglowodany'];
										$bialko = $row['bialko'];

										$rezultat = $polaczenie->query("SELECT * FROM obliczane_kalorie WHERE id_user = '$id_user' AND nr_data = '$data'");
										$rezultat2 = $polaczenie->query("SELECT * FROM pora_dnia WHERE id_user = '$id_user' AND nr_data = '$data' AND posilek = '$selected'");

										if (!$rezultat) {
											throw new Exception($polaczenie->error);
										}
										if (!$rezultat2) {
											throw new Exception($polaczenie->error);
										}
										$liczbaWierszy = $rezultat->num_rows;
										$liczbaWierszy2 = $rezultat2->num_rows;
										if ($liczbaWierszy > 0) {
											$polaczenie->query("UPDATE obliczane_kalorie SET kcal = kcal+$kcal, tluszcze = tluszcze+$tluszcze, weglowodany=weglowodany+$weglowodany, bialko=bialko+$bialko WHERE nr_data = '$data' AND id_user = '$id_user'");
										} else {
											$polaczenie->query("INSERT INTO obliczane_kalorie (nr_data, kcal, tluszcze, weglowodany, bialko, id_user) VALUES ('$data', '$kcal', '$tluszcze', '$weglowodany', '$bialko', '$id_user')");
										}

										$polaczenie->query("INSERT INTO pora_dnia (nr_data, id_user, posilek, id_produktu) VALUES ('$data', '$id_user', '$selected', '$id_produktu')");


										$pora_dnia = "SELECT * FROM pora_dnia WHERE id_user = '$id_user' AND nr_data = '$data' AND posilek = '$selected'";

										$pyt = $polaczenie->query("SELECT * FROM obliczane_kalorie WHERE id_user = '$id_user' AND nr_data = '$data'");

										$pyt3 = $polaczenie->query("SELECT * FROM produkty p INNER JOIN pora_dnia pd ON pd.id_produktu = p.id WHERE pd.nr_data = '$data' AND pd.id_user = '$id_user' ORDER BY case when posilek = 'sniadanie' then 1
										when posilek = 'obiad' then 2
										when posilek = 'przekaska' then 3
										when posilek = 'kolacja' then 4
										else posilek END ASC");

										if (!$pyt3) {
											printf("Error: %s\n", mysqli_error($polaczenie));
											exit();
										}

										echo '<div class="col-6">';
										echo '<table class="formContent">';
										echo '<tr><th>' . "Pora dnia" . '</th>';
										echo '<th>' . "Produkt" . '</th>';
										echo '<th>' . "Kcal" . '</th>';
										echo '<th>' . "Tłuszcze" . '</th>';
										echo '<th>' . "Węglowodany" . '</th>';
										echo '<th>' . "Białko" . '</th></tr>';
										while ($row = mysqli_fetch_array($pyt3)) {
											echo '<tr><td>' . $row['posilek'] . '</td><td>' . $row['nazwa'] . '</td>' . '<td>' .
												$row["kcal"] . '</td>' . '<td>' . " " . $row["tluszcze"] . '</td>' . '<td>' .
												$row["weglowodany"] . '</td>' . '<td>'
												. $row["bialko"] . '</td></tr>';
										}
										echo '</table>';

										echo '</div>';
									}
								}
								else {
									echo '<script>alert("Brak produktu w bazie")</script>';
								}
							}

						}
						else {
							$flag = false;
							echo '<script>alert("Wpisz wszystkie dane")</script>';
						}
					}
				}
				$polaczenie->close();

				?>

			</div>
		</div>
	</section>

</body>

</html>