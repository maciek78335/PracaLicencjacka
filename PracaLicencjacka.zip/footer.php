<footer>
		<div class="info">Autor: Maciej Wszeborowski</div>
</footer>
