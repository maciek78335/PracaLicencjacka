<!DOCTYPE html>
<html lang="pl">
<head>
<body>
<form method="post" action="handle_form.php">
    <label for="allow_access">
        <input type="hidden" name="allow_access" value="0">
        <input type="checkbox" name="allow_access" value="1" id="allow_access">Allow
    </label>
    <button type="submit">Send</button>
</form>

</body>

</head>
</html>