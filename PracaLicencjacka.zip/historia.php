<?php session_start();

require_once 'connect.php';
require_once 'nawigacja.php' ?>

<!DOCTYPE html>
<html lang="pl">

<head>
    <style>
        .formContent {
            background-color: #E0E0E0;
            color: black;
            margin-bottom:10px;
            text-align: center;
            margin-left: auto;
			margin-right: auto;
            padding: 40px;
            margin-top: 10px;

        }



        td {
            border: 1px solid;
            padding: 5px;
        }

        th {
            background-color: #04AA6D;
            border: 1px solid;
            padding: 10px;

        }

        .historia form {
            background-color: #E0E0E0;
            color: black;
            padding: 30px;
            margin-top: 20px;
            width: 250px;
            text-align: center;
            margin-left: auto;
            margin-right: auto;

        }

        input[type=date] {
            background-color: #efefef;
            border: 2px solid #ddd;
            border-radius: 5px;
            padding: 5px;
            box-sizing: border-box;
        }

        input[type=submit] {
            background-color: #36b03c;
            width: 90px;
            font-size: 15px;
            color: white;
            padding: 5px 5px;
            margin-top: 5px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>

</head>

<body>
    <section class="historia">

        <div class="row no-gutters">

            <div class="col-sm-6">
                <form class="form-content" action="" method="post">
                    Podaj przedział czasowy: <br /><br /> <input type="date" name="data_od" /> <br /><br />
                    <input type="date" name="data_do" /> <br /><br />
                    <input type="submit" name="submit" value="Wyszukaj" />
                </form>
            </div>

            <?php

            $id_user = $_SESSION['id'];
            if (isset($_SESSION['zalogowany'])) {
                if (isset($_POST['submit'])) {
                    if (!empty($_POST['data_od']) && !empty($_POST['data_do'])) {
                        $flag = true;
                        $dataOd = $_POST['data_od'];
                        $dataDo = $_POST['data_do'];

                        $zapytanie = "SELECT * FROM produkty p INNER JOIN pora_dnia pd ON pd.id_produktu = p.id WHERE pd.id_user = '$id_user' AND pd.nr_data BETWEEN '$dataOd' AND '$dataDo' ORDER BY pd.nr_data, case when posilek = 'sniadanie' then 1
                        when posilek = 'obiad' then 2
                        when posilek = 'przekaska' then 3
                        when posilek = 'kolacja' then 4
                        else posilek END ASC";

                        $pyt = $polaczenie->query("SELECT * FROM obliczane_kalorie WHERE id_user = '$id_user' AND nr_data BETWEEN '$dataOd' AND '$dataDo' ORDER BY nr_data");

                        $rezultat = $polaczenie->query($zapytanie);

                        echo '<div class="col-sm-6">';
                        echo '<h3 style="text-align:center; margin-top:10px; ">Podsumowanie kaloryczne wybranych dni:</h3>';
                        echo '<table class="formContent">';
                        echo '<tr><th>' . "Data" . '</th>';
                        echo '<th>' . "Kcal" . '</th>';
                        echo '<th>' . "Tłuszcze" . '</th>';
                        echo '<th>' . "Węglowodany" . '</th>';
                        echo '<th>' . "Białko" . '</th></tr>';
                        while ($row = mysqli_fetch_array($pyt)) {
                            echo '<tr><td>' . $row['nr_data'] . '</td>' . '<td>' .
                                $row["kcal"] . '</td>' . '<td>' . " " . $row["tluszcze"] . '</td>' . '<td>' .
                                $row["weglowodany"] . '</td>' . '<td>'
                                . $row["bialko"] . '</td></tr>';
                        }
                        echo '</table>';
                        echo '</div>';


                        echo '<div class="col-sm-6"></div>';
                        echo '<div class="col-sm-6">';
                        echo '<h3 style="text-align:center;">Podsumowanie diety z wybranych dni:</h3>';
                        echo '<table class="formContent">';
                        echo '<tr><th>' . "Data" . '</th>';
                        echo '<th>' . "Posiłek" . '</th>';
                        echo '<th>' . "Produkt" . '</th>';
                        echo '<th>' . "Kcal" . '</th>';
                        echo '<th>' . "Tłuszcze" . '</th>';
                        echo '<th>' . "Węglowodany" . '</th>';
                        echo '<th>' . "Białko" . '</th>';
                        if (mysqli_query($polaczenie, $zapytanie)) {
                            while ($row = mysqli_fetch_array($rezultat)) {
                                echo '<tr><td>' . $row['nr_data'] . '</td>' . '<td>' .
                                    $row["posilek"] . '</td>' . '<td>' . " " . $row["nazwa"] . '</td>' . '<td>' .
                                    $row["kcal"] . '</td>' . '<td>'
                                    . $row["tluszcze"] . '</td>' . '<td>' . $row["weglowodany"] . '</td>' . '<td>' . $row['bialko'] . '</td></tr>';
                            }

                            echo '</table>';
                            echo '</div>';
                        }
                    } else {
                        $flag = false;
                        echo '<script>alert("Zaznacz przedział czasowy")</script>';
                    }
                }
            }

            $polaczenie->close();
            ?>

            <?php echo '</div>'; ?>
    </section>

</body>

</html>