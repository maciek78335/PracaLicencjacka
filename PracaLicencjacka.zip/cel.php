<?php session_start();

require_once 'connect.php';
?>

<?php require_once 'nawigacja.php' ?>

<!DOCTYPE HTML>
<html lang="pl">

<head>
	<meta charset="utf-8" />
	<title>Cele</title>


	<style>
		.formContent {
			margin-bottom: 10px;
			text-align: center;
			background-color: #E0E0E0;
			color: black;
			width: 370px;
			padding: 15px;
			margin-top: 10px;
		}

		.cele {
			margin-bottom: 10px;
			text-align: center;
			margin-left: auto;
			margin-right: auto;
			background-color: #E0E0E0;
			color: black;
			margin-top: 20px;
		}

		.tabele table {
			margin-top: 20px;
			margin-left: auto;
			margin-right: auto;
		}

		.tabele .wyborCelow {
			margin-left: 120px;
		}

		.przyciski {
			margin-left: auto;
			margin-right: auto;
		}

		.tabele h3 {
			text-align: center;
		}

		input[type=text],
		input[type=date] {
			width: 300px;
			background-color: #efefef;
			color: #666;
			border: 2px solid #ddd;
			border-radius: 5px;
			font-size: 15px;
			padding: 5px;
			box-sizing: border-box;
			outline: none;
			margin-top: 10px;
		}

		input[type=submit] {
			width: 280px;
			background-color: #36b03c;
			font-size: 15px;
			color: white;
			padding: 10px 5px;
			margin-top: 20px;
			border: none;
			border-radius: 5px;
			cursor: pointer;

		}

		input[type=submit]:hover {
			background-color: #37b93d;
		}

		td {
			border: 1px solid;

			padding: 5px;
		}

		th {
			background-color: #04AA6D;
			border: 1px solid;
			padding: 10px;

		}
	</style>
</head>

<body>
	<?php
	function wyswietlNiezrealizowaneCele()
	{

		$host = "localhost";
		$db_user = "root";
		$db_password = "";
		$db_name = "pomiary";
		$polaczenie = mysqli_connect($host, $db_user, $db_password, $db_name);

		$id_user = $_SESSION['id'];
		$query = "SELECT * FROM cele WHERE id_user = '$id_user' AND czy_zrealizowano = 0";
		$wynikZapytania = $polaczenie->query($query);

		echo '<div class="col-sm-6">';
		echo '<h3 style="text-align:center; margin-top:10px; ">Niezrealizowane cele</h3>';
		echo '<table class="cele">';
		echo '<tr><th>' . "Cel" . '</th>';
		echo '<th>' . "Data osiągnięcia" . '</th>';
		echo '<th>' . "Cel zrealizowany?" . '</th>';
		if (mysqli_query($polaczenie, $query)) {
			while ($row = mysqli_fetch_array($wynikZapytania)) { ?>

				<form action="check.php" method="post">
					<tr>
						<td><?php echo $row['tresc']; ?></td>
						<td><?php echo $row['data_nr']; ?></td>
						<td><a href="check.php?id=<?php echo $row['id']; ?>"><input type="checkbox" name="checkAccount" /></a></td>

					</tr>
				</form>
	<?php


			}
		}
		echo '</table>';
		echo '</div>';
		$polaczenie->close();
	}
	?>

	<?php
	function wyswietlZrealizowaneCele()
	{

		$host = "localhost";
		$db_user = "root";
		$db_password = "";
		$db_name = "pomiary";
		$polaczenie = mysqli_connect($host, $db_user, $db_password, $db_name);

		$id_user = $_SESSION['id'];
		$query = "SELECT * FROM cele WHERE id_user = '$id_user' AND czy_zrealizowano = 1";
		$wynikZapytania = mysqli_query($polaczenie, $query);

		echo '<div class="col-sm-6">';
		echo '<h3 style="text-align:center; margin-top:10px; ">Zrealizowane cele</h3>';
		echo '<table class="cele">';
		echo '<tr><th>' . "Cel" . '</th>';
		echo '<th>' . "Data osiągnięcia" . '</th></tr>';
		while ($row = mysqli_fetch_array($wynikZapytania)) {
			echo '<tr><td>' . $row['tresc'] . '</td>' . '<td>' .
				$row['data_nr'] . '</td></tr>';
		}
		echo '</table>';
		echo '</div>';
		$polaczenie->close();
	}

	echo '<section class="tabele">';
	echo '<div class="container">';
	echo '<div class="row">';
	if (isset($_SESSION['zalogowany'])) {

		if (isset($_POST['cel'])) {
			if (!empty($_POST['cel']) && !empty($_POST['koniec'])) {
				$flaga = true;
				$idUsera = $_SESSION['id'];
				$cel =  mysqli_real_escape_string($polaczenie, $_REQUEST['cel']);
				$data =  mysqli_real_escape_string($polaczenie, $_REQUEST['koniec']);
				$_SESSION['czy_zrealizowano'] = 0;
				$czy_zrealizowano = $_SESSION['czy_zrealizowano'];
				$ktoryUzytkownik = "SELECT 'tresc', 'data_nr' FROM cele WHERE id_user = $idUsera";


				$polaczenie->query("INSERT INTO cele(`tresc`, `data_nr`, `czy_zrealizowano`, `id_user`) VALUES ('$cel', '$data', '$czy_zrealizowano', '$idUsera')");
			} else {
				$flaga = false;
				echo '<script>alert("Wpisz wszystkie dane")</script>';
			}
		}
		$polaczenie->close();
	}

	?>

	<div class="col-sm-6">
		<div class="formContent">
			<form action="" method="post">
				Cel do osiągnięcia: <br /> <input type="text" name="cel" /> <br /><br />
				Data zakończenia: <br /> <input type="date" name="koniec"> <br /><br />
				<input type="submit" value="Dodaj cel" />
			</form>
		</div>
	</div>

	<?php
	if (isset($_POST['wybor'])) {
		$wybrany = $_POST['wybor'];
		if (!empty($wybrany) && $wybrany=='niezrealizowaneCele' || $wybrany=='zrealizowaneCele') {
			$flaga = true;

			switch ($wybrany) {
				case 'niezrealizowaneCele':
					echo wyswietlNiezrealizowaneCele();
					break;
				case 'zrealizowaneCele':
					echo wyswietlZrealizowaneCele();
					break;
				default:
					echo '<script>alert("Zaznacz rodzaj celów")</script>';
					break;
			}
		} else {
			$flaga = false;
			echo '<script>alert("Zaznacz rodzaj celów")</script>';
		}
	}

	?>


	<div class="col-12">
		<div class="formContent">

			<form method="post">
				Wybierz, co chcesz zrobić: </br> <select name="wybor">
					<option value="" disabled selected>Wybierz, co chcesz zrobić: </option>
					<option value="niezrealizowaneCele">Wyświetl niezrealizowane cele</option>
					<option value="zrealizowaneCele">Wyświetl zrealizowane cele</option>
				</select> <br /><br />
				<input type="submit" value="Wyświetl" />
			</form>

		</div>
	</div>

	<?php echo '</div>';
	echo '</div>';
	echo '</section>'; ?>

</body>

</html>